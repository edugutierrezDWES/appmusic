# MODO DE TRABAJO
Muy buenas equipo, para la organización y que luego no haya ningún problema la hora de juntar lo que hace cada uno 
me gustaría establecer ciertos criterios. Si tenéis alguna sugerencia o queréis cambiar algo me lo podéis decir sin problema.

1. Vamos a utilizar Trello para organizarnos, https://trello.com/invite/b/DstAA5KZ/ced8e3768fef9aabb204caf5db97e4d5/proyecto-php. Podéis entrar mediante esta 
invitación pero tenéis que estar registrado antes.
Se trata de una página específica para proyectos. Ahí se puede ver en el tablero que he creado 4 secciones y cada sección tiene varios apartados, cuando se
termine una tarea se va a mover esa tarea al estado correspondiente. 

2. Como dijo Alfonso todos vamos a tener que crear las carpetas del MVC y van a tener los nombres del PDF (models, controllers, views, db y por último nuestro index.php)

3. Si os parece bien a todos vamos a utilizar PDO para la conexión a la base de datos.

4. Cada función retornará los datos correspondientes y en caso contrario retornará null. Los errores también se controlan en la propias funciones.

5. Todas las funciones tienen que estar bien comentadas y los nombres de las variables tanto como de las funciones en el mismo idioma (haremos una votación)

Eso es todo de momento
Gracias!!!
