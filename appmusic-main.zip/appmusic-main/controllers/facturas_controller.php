<?php
	require_once("models/facturas_model.php");
    require_once("views/facturas_view.php");
	
?>